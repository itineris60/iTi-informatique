let menuinfo = document.querySelector(".menu-informatique");
var submenu = document.querySelector(".sub-menu-informatique");
submenu.style.display = "none";

document.querySelector(".menu-informatique").addEventListener("mouseenter", handlemouseover);
function handlemouseover(event) {
    submenu.style.display = "flex";
}

window.addEventListener("mousemove", handlehidemenu);
function handlehidemenu(event) {
    let target = event.target;
    if (target === menuinfo) {
        return;
    }
    if (target === submenu) {
        return;
    }
    if (target.parentNode) {
        if (target.parentNode === submenu) {
            return;
        }
        if (target.parentNode.parentNode) {
            if (target.parentNode.parentNode === submenu) {
                return;
            }
        }
    }
    console.log(event.target);
    submenu.style.display = "none";
}